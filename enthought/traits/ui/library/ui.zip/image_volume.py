from enthought.traits.ui.image import ImageVolume, ImageVolumeInfo
    
volume = ImageVolume(
    category    = 'General',
    keywords    = [],
    aliases     = [],
    info        = [
        ImageVolumeInfo(
            description = 'Core Traits UI Icons and Themes.',
            copyright   = """Copyright (c) 2007 by Enthought, Inc.
All rights reserved.""",
            license     = """This software is provided without warranty under the terms of the BSD
license included in enthought/LICENSE.txt and may be redistributed only
under the conditions described in the aforementioned license.  The license
is also available online at http://www.enthought.com/licenses/BSD.txt

Thanks for using Enthought open source!""",
            image_names = []
        )
    ]
)