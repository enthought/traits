from enthought.traits.ui.image import ImageVolume, ImageVolumeInfo
    
volume = ImageVolume(
    category    = 'Themes',
    keywords    = [],
    aliases     = [],
    time_stamp  = '20080125125836',
    info        = [
        ImageVolumeInfo(
            description = 'A collection of images suitable for use as Traits UI themes.\nAll images created by: David C. Morrill.',
            copyright   = 'Copyright (c) 2007, Enthought, Inc. All rights reserved.',
            license     = 'These images are provided without warranty under the terms of the BSD\nlicense included in enthought/LICENSE.txt and may be redistributed only\nunder the conditions described in the aforementioned license.  The license\nis also available online at http://www.enthought.com/licenses/BSD.txt\n\nThanks for using Enthought open source!\n',
            image_names = []
        )
    ]
)