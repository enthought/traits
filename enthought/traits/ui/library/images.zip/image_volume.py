from enthought.traits.ui.image import ImageVolume, ImageVolumeInfo
    
volume = ImageVolume(
    category    = 'Themes',
    keywords    = [],
    aliases     = [],
    info        = [
        ImageVolumeInfo(
            description = """A collection of images suitable for use as Traits UI themes.
All images created by: David C. Morrill.""",
            copyright   = 'Copyright (c) 2007, Enthought, Inc. All rights reserved.',
            license     = """These images are provided without warranty under the terms of the BSD
license included in enthought/LICENSE.txt and may be redistributed only
under the conditions described in the aforementioned license.  The license
is also available online at http://www.enthought.com/licenses/BSD.txt

Thanks for using Enthought open source!
""",
            image_names = []
        )
    ]
)